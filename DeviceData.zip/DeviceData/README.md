All data recorded in-browser. Some of the folders have notes on what actions I was doing while recording. Other recordings are older so I don't know.

The IIR filters I used are here for the filtered datasets: https://github.com/joshbrew/BiquadFilters.js

The ECG and PPG clean up pretty well just with lowpass filters but the main issue are the motion artifacts. The ECG otherwise I need to improve the contact points so the 2nd unfiltered recoding and the 45hz lowpass recording are kind of meh already but I can see the QRST waves.


The full bench can record event data and also audio/video and experimentally also face/eye-tracking data alongside the biometrics, so plan is to put all of that to work for helping classify psychological states, primarily stress as it's the most general for our use case of working with psych patients. We are most concerned with the signal quality right now, however.