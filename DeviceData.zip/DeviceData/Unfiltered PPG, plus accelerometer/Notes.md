Sequence:

0-10s
Moved hand in several directions,

10-20s
Banged hand against body and soft furniture.

20-30s
Shook hand wildly.

30-35s
Moved left and right

Then Till end:
Held still.